package lab4;

public class De extends ConVat {
	public void Keu() {
		System.out.println("Maa...Maa...!");
	}
}
