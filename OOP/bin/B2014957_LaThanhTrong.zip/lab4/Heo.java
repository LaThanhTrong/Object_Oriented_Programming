package lab4;

public class Heo extends ConVat {
	public void Keu() {
		System.out.println("Oink...Oink...!");
	}
}
