package lab4;

public class Ga extends ConVat {
	public void Keu() {
		System.out.println("Cluck...Cluck...!");
	}
}
