package lab4;

public class Bo extends ConVat {
	public void Keu() {
		System.out.println("Moo..Moo..!");
	}
}
